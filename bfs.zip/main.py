graph = {
  'Sam' : ['Grant','Connor'],
  'Grant' : ['Wyatt', 'Izayuh'],
  'Connor' : ['Dunngie'],
  'Wyatt' : [],
  'Izayuh' : ['Dunngie'],
  'Dunngie' : []
} #adjacency list where each vertex has a stored list of it's adjacent nodes..
visited = []
queue = []
rate = .75 #75%
samInfected = 1 #100%


def bfs(visited, graph, node):
  visited.append(node)
  queue.append(node)

  while queue:
    s = queue.pop(0) 
    print (s, end = " ") 
    edgeProb1 = rate *samInfected
    edgeProb2 = rate * edgeProb1
  #need to keep multiplying rate by the new edgeprobability...
  # how many times? 1000 to match the testdata?
    for i in range (10):
      edgeProb2 = rate *edgeProb2 #replacing edgeProb2  with this?

    for neighbour in graph[s]:
      if neighbour not in visited:
        visited.append(neighbour)
        queue.append(neighbour)
        print(graph[s], "'s infection probability is: ", samInfected) #base
        print(graph[s] , "'s infection probability is: ", rate*samInfected ) # supposed to be sam to grant & connor
        print(graph[s], "'s infection probability is: ", rate*edgeProb1) #supposed to be connor & grant to wyatt, izayuh, dunngie
        print(graph[s], "'s infection probability is: ", rate*edgeProb2) #izayuh to dunngie
        

# Driver Code
bfs(visited, graph, 'Sam')





#dequeue slot 1

#if success, return edge (probability)

#if fail, continue -> for loop explore surrounding
#nodes
